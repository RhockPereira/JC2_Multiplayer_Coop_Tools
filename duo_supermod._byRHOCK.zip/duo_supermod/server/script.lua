--[[
================================================================================
  duo_supermod - server/script.lua
  Versao: 1.0.0
  Autor: Jogador

  Main commands (English):
    /list
    /skin
    /skin 1
    /skin 2
    /skin policial
    /skin gangue
    /skin padrao
    /skin id NUMERO

    /veiculos
    /moto
    /heli
    /aviao
    /carro
    /veh id NUMERO

    /duo
    /duo set NOME
    /duo limpar
    /tpduo
    /trazerduo
    /duostatus
    /localizarduo
================================================================================
]]

-- ============================================================
-- CONFIGURACAO CENTRAL
-- ============================================================
-- IDs mantidos iguais aos do arquivo original de proposito.
-- Assim esta correcao nao muda silenciosamente quais modelos voce escolheu.
Config = {
    DEBUG = true,

    SKINS = {
        ["1"]       = { name = "Rhock",   id = 1  },
        ["2"]       = { name = "Partner", id = 2  },
        ["police"]  = { name = "Police",  id = 21 },
        ["gang"]    = { name = "Gang",    id = 10 },
        ["default"] = { name = "Default", id = 0  },

        -- Legacy Portuguese aliases kept for compatibility
        ["policial"] = { name = "Police",  id = 21 },
        ["gangue"]   = { name = "Gang",    id = 10 },
        ["padrao"]   = { name = "Default", id = 0  },
    },

    VEHICLES = {
        bike  = { name = "Motorcycle", id = 1 },
        heli  = { name = "Helicopter", id = 2 },
        plane = { name = "Plane",      id = 3 },
        car   = { name = "Car",        id = 4 },

        -- Legacy Portuguese aliases kept for compatibility
        moto  = { name = "Motorcycle", id = 1 },
        aviao = { name = "Plane",      id = 3 },
        carro = { name = "Car",        id = 4 },
    },

    VEHICLE_COOLDOWN_SECONDS  = 10,
    TELEPORT_COOLDOWN_SECONDS = 5,
    SPAWN_DISTANCE            = 8,
}

-- ============================================================
-- ESTADO
-- ============================================================
DuoPairs      = {}
VehCooldown   = {}
TpCooldown    = {}
PlayerVehicles = {}

-- ============================================================
-- AUXILIARES
-- ============================================================

function DebugLog(message)
    if Config.DEBUG then
        print("[duo_supermod] " .. tostring(message))
    end
end

function GetPlayerName(player)
    if player == nil then
        return "Desconhecido"
    end

    return tostring(player:GetName())
end

function GetPlayerKey(player)
    if player == nil then
        return nil
    end

    -- SteamId e a chave preferida para o duo continuar associado
    -- mesmo se o jogador sair e entrar novamente.
    local steamId = player:GetSteamId()
    if steamId ~= nil then
        local text = tostring(steamId)
        if text ~= "" and text ~= "0" then
            return "steam_" .. text
        end
    end

    return "name_" .. GetPlayerName(player)
end

function SendChat(player, message, color)
    if player == nil or not IsValid(player) then
        return
    end

    Chat:Send(
        player,
        "[duo_supermod] " .. tostring(message),
        color or Color(255, 255, 255)
    )
end

function GetAllPlayers()
    local players = {}

    for player in Server:GetPlayers() do
        table.insert(players, player)
    end

    return players
end

-- Primeiro procura nome exato; depois mantem a busca parcial do mod original.
function FindPlayerByName(name)
    if name == nil then
        return nil
    end

    local query = string.lower(tostring(name))
    if query == "" then
        return nil
    end

    local players = GetAllPlayers()

    for _, player in ipairs(players) do
        if string.lower(GetPlayerName(player)) == query then
            return player
        end
    end

    for _, player in ipairs(players) do
        local playerName = string.lower(GetPlayerName(player))
        if string.find(playerName, query, 1, true) then
            return player
        end
    end

    return nil
end

function GetOtherOnlinePlayer(player)
    local myKey = GetPlayerKey(player)
    local count = 0
    local other = nil

    for onlinePlayer in Server:GetPlayers() do
        count = count + 1

        if GetPlayerKey(onlinePlayer) ~= myKey then
            other = onlinePlayer
        end
    end

    if count == 2 then
        return other
    end

    return nil
end

function GetPlayerPosition(player)
    if player == nil or not IsValid(player) then
        return nil
    end

    return player:GetPosition()
end

function SetPlayerPosition(player, position)
    if player == nil or position == nil or not IsValid(player) then
        return false
    end

    local ok, err = pcall(function()
        player:SetPosition(position)
    end)

    if not ok then
        DebugLog("Falha em SetPosition: " .. tostring(err))
    end

    return ok
end

function GetPlayerAngle(player)
    if player == nil or not IsValid(player) then
        return nil
    end

    return player:GetAngle()
end

function GetForwardPosition(player, distance)
    local position = GetPlayerPosition(player)
    local angle = GetPlayerAngle(player)

    if position == nil or angle == nil then
        return nil
    end

    local dist = distance or Config.SPAWN_DISTANCE
    local forward = angle * Vector3.Forward

    return position + (forward * dist)
end

function GetTime()
    return Server:GetElapsedSeconds()
end

function CheckCooldown(cooldownTable, key, seconds)
    local now = GetTime()
    local last = cooldownTable[key] or -seconds
    local elapsed = now - last

    if elapsed >= seconds then
        cooldownTable[key] = now
        return true, 0
    end

    return false, seconds - elapsed
end

-- ============================================================
-- SKINS
-- ============================================================

function ApplySkin(player, skinId, skinName)
    local id = tonumber(skinId)

    if id == nil then
        SendChat(player, "ID de skin invalido: " .. tostring(skinId))
        return false
    end

    local ok, err = pcall(function()
        player:SetModelId(id)
    end)

    if not ok then
        DebugLog("Falha ao aplicar skin ID=" .. tostring(id) .. ": " .. tostring(err))
        SendChat(player, "Nao foi possivel aplicar a skin ID " .. tostring(id) .. ". Veja o console.")
        return false
    end

    local name = skinName or ("ID " .. tostring(id))
    DebugLog("Skin aplicada: " .. name .. " | ID=" .. tostring(id) .. " | Jogador=" .. GetPlayerName(player))
    SendChat(player, "Skin '" .. name .. "' aplicada!")
    return true
end

function HandleSkinCommand(player, args)
    if args == nil or args[1] == nil or args[1] == "" then
        SendChat(player, "=== Skins disponiveis ===")
        SendChat(player, "/skin default | /skin 1 (Rhock) | /skin 2 (Partner) | /skin police | /skin gang")
        SendChat(player, "/skin id NUMBER - test any numeric model ID")
        return
    end

    local sub = string.lower(args[1])

    if sub == "id" then
        local id = tonumber(args[2])

        if id == nil then
            SendChat(player, "Usage: /skin id NUMBER")
            return
        end

        ApplySkin(player, id, "ID-" .. tostring(id))
        return
    end

    local skinData = Config.SKINS[sub]
    if skinData ~= nil then
        ApplySkin(player, skinData.id, skinData.name)
        return
    end

    local directId = tonumber(sub)
    if directId ~= nil then
        ApplySkin(player, directId, "ID-" .. tostring(directId))
        return
    end

    SendChat(player, "Skin '" .. tostring(sub) .. "' nao encontrada. Use /skin para ver a lista.")
end

-- ============================================================
-- VEICULOS
-- ============================================================

function RemovePreviousVehicle(player)
    local key = GetPlayerKey(player)
    if key == nil then
        return
    end

    local vehicle = PlayerVehicles[key]

    if vehicle ~= nil and IsValid(vehicle) then
        local ok, err = pcall(function()
            vehicle:Remove()
        end)

        if not ok then
            DebugLog("Falha ao remover veiculo anterior: " .. tostring(err))
        end
    end

    PlayerVehicles[key] = nil
end

function TryCreateVehicle(vehicleId, position, angle, world)
    local ok, vehicleOrError = pcall(function()
        return Vehicle.Create({
            model_id = tonumber(vehicleId),
            position = position,
            angle = angle,
            world = world,
        })
    end)

    if not ok then
        DebugLog("Vehicle.Create falhou: " .. tostring(vehicleOrError))
        return nil
    end

    return vehicleOrError
end

function TryEnterVehicle(player, vehicle)
    if player == nil or vehicle == nil then
        return false
    end

    if not IsValid(player) or not IsValid(vehicle) then
        return false
    end

    local ok, err = pcall(function()
        player:EnterVehicle(vehicle, VehicleSeat.Driver)
    end)

    if not ok then
        DebugLog("EnterVehicle falhou: " .. tostring(err))
        return false
    end

    return true
end

function SpawnVehicleForPlayer(player, vehicleId, vehicleName)
    local key = GetPlayerKey(player)
    if key == nil then
        return
    end

    local cooldownOk, remaining = CheckCooldown(
        VehCooldown,
        key,
        Config.VEHICLE_COOLDOWN_SECONDS
    )

    if not cooldownOk then
        SendChat(player, "Aguarde " .. math.ceil(remaining) .. "s para spawnar outro veiculo.")
        return
    end

    local spawnPosition = GetForwardPosition(player, Config.SPAWN_DISTANCE)
    local angle = GetPlayerAngle(player)

    if spawnPosition == nil or angle == nil then
        SendChat(player, "Erro ao calcular a posicao do veiculo.")
        return
    end

    RemovePreviousVehicle(player)

    local vehicle = TryCreateVehicle(
        vehicleId,
        spawnPosition,
        angle,
        player:GetWorld()
    )

    if vehicle == nil or not IsValid(vehicle) then
        SendChat(player, "Nao foi possivel criar o veiculo. Veja o console.")
        return
    end

    PlayerVehicles[key] = vehicle

    local name = vehicleName or ("Veiculo ID " .. tostring(vehicleId))
    DebugLog("Veiculo '" .. name .. "' (ID=" .. tostring(vehicleId) .. ") criado para " .. GetPlayerName(player))

    if TryEnterVehicle(player, vehicle) then
        SendChat(player, "Veiculo '" .. name .. "' spawnado! Voce esta dentro.")
    else
        SendChat(player, "Veiculo '" .. name .. "' spawnado perto de voce.")
    end
end

function HandleVehicleCommand(player, command, args)
    if command == "veh" then
        if args == nil or string.lower(args[1] or "") ~= "id" then
            SendChat(player, "Usage: /veh id NUMBER")
            return
        end

        local id = tonumber(args[2])

        if id == nil then
            SendChat(player, "Usage: /veh id NUMBER")
            return
        end

        SpawnVehicleForPlayer(player, id, "Veiculo-" .. tostring(id))
        return
    end

    if command == "vehicles" or command == "veiculos" then
        SendChat(player, "=== Veiculos ===")
        SendChat(player, "/bike | /heli | /plane | /car")
        SendChat(player, "/veh id NUMBER - test any vehicle model ID")
        return
    end

    local vehicleData = Config.VEHICLES[command]
    if vehicleData ~= nil then
        SpawnVehicleForPlayer(player, vehicleData.id, vehicleData.name)
        return
    end

    SendChat(player, "Comando de veiculo desconhecido: /" .. tostring(command))
end

-- ============================================================
-- DUO / CO-OP
-- ============================================================

function CalculateDistance(position1, position2)
    if position1 == nil or position2 == nil then
        return 9999
    end

    return Vector3.Distance(position1, position2)
end

function PosWithOffset(position, offsetX, offsetZ)
    if position == nil then
        return nil
    end

    return position + Vector3(offsetX or 2, 0, offsetZ or 0)
end

function GetDuoPartner(player)
    local key = GetPlayerKey(player)
    local partnerName = key and DuoPairs[key] or nil

    if partnerName ~= nil and partnerName ~= "" then
        local partner = FindPlayerByName(partnerName)

        if partner ~= nil then
            return partner
        end

        return nil, "offline"
    end

    local other = GetOtherOnlinePlayer(player)
    if other ~= nil then
        return other
    end

    return nil, "nao_configurado"
end

function HandleDuoCommand(player, args)
    local sub = args and args[1] and string.lower(args[1]) or nil

    if sub == nil or sub == "" then
        SendChat(player, "=== Sistema DUO ===")
        SendChat(player, "/duo set NAME - set your duo partner by name")
        SendChat(player, "/duo clear - clear your configured duo partner")
        SendChat(player, "/tpduo - teleport to your duo")
        SendChat(player, "/bringduo - bring your duo to you")
        SendChat(player, "/duostatus - show duo status and distance")
        SendChat(player, "/findduo - show duo position and distance")
        return
    end

    if sub == "set" then
        local targetName = ""

        if args ~= nil and #args >= 2 then
            targetName = table.concat(args, " ", 2)
        end

        if targetName == "" then
            SendChat(player, "Usage: /duo set NAME")
            return
        end

        local target = FindPlayerByName(targetName)
        local key = GetPlayerKey(player)

        if target ~= nil and GetPlayerKey(target) == key then
            SendChat(player, "Voce nao pode definir voce mesmo como duo.")
            return
        end

        if target ~= nil then
            DuoPairs[key] = GetPlayerName(target)
            SendChat(player, "Duo definido: " .. GetPlayerName(target))
        else
            DuoPairs[key] = targetName
            SendChat(player, "Duo definido como '" .. targetName .. "' (offline no momento).")
        end

        DebugLog("Duo definido: " .. GetPlayerName(player) .. " -> " .. DuoPairs[key])
        return
    end

    if sub == "clear" or sub == "limpar" then
        local key = GetPlayerKey(player)
        if key ~= nil then
            DuoPairs[key] = nil
        end

        SendChat(player, "Duo removido.")
        DebugLog("Duo removido para: " .. GetPlayerName(player))
        return
    end

    SendChat(player, "Subcomando desconhecido. Use /duo para ajuda.")
end

function HandleTpDuo(player)
    local key = GetPlayerKey(player)

    local cooldownOk, remaining = CheckCooldown(
        TpCooldown,
        key,
        Config.TELEPORT_COOLDOWN_SECONDS
    )

    if not cooldownOk then
        SendChat(player, "Aguarde " .. math.ceil(remaining) .. "s para teleportar novamente.")
        return
    end

    local partner, reason = GetDuoPartner(player)

    if partner == nil then
        if reason == "offline" then
            SendChat(player, "Seu duo esta offline no momento.")
        else
            SendChat(player, "Duo nao configurado. Use /duo set NOME ou jogue com exatamente 2 jogadores.")
        end
        return
    end

    local targetPosition = GetPlayerPosition(partner)

    if targetPosition == nil then
        SendChat(player, "Nao foi possivel obter posicao do duo.")
        return
    end

    local newPosition = PosWithOffset(targetPosition, 2, 0)

    if not SetPlayerPosition(player, newPosition) then
        SendChat(player, "Falha ao teleportar.")
        return
    end

    SendChat(player, "Teleportado para " .. GetPlayerName(partner) .. "!")
    SendChat(partner, GetPlayerName(player) .. " teleportou ate voce.")
    DebugLog(GetPlayerName(player) .. " tp ate " .. GetPlayerName(partner))
end

function HandleTrazarDuo(player)
    local key = GetPlayerKey(player)

    local cooldownOk, remaining = CheckCooldown(
        TpCooldown,
        key,
        Config.TELEPORT_COOLDOWN_SECONDS
    )

    if not cooldownOk then
        SendChat(player, "Aguarde " .. math.ceil(remaining) .. "s para teleportar novamente.")
        return
    end

    local partner, reason = GetDuoPartner(player)

    if partner == nil then
        if reason == "offline" then
            SendChat(player, "Seu duo esta offline no momento.")
        else
            SendChat(player, "Duo nao configurado. Use /duo set NOME ou jogue com exatamente 2 jogadores.")
        end
        return
    end

    local myPosition = GetPlayerPosition(player)

    if myPosition == nil then
        SendChat(player, "Nao foi possivel obter sua posicao.")
        return
    end

    local newPosition = PosWithOffset(myPosition, 2, 0)

    if not SetPlayerPosition(partner, newPosition) then
        SendChat(player, "Falha ao trazer seu duo.")
        return
    end

    SendChat(player, GetPlayerName(partner) .. " foi trazido para voce!")
    SendChat(partner, GetPlayerName(player) .. " te trouxe para perto.")
    DebugLog(GetPlayerName(partner) .. " foi trazido ate " .. GetPlayerName(player))
end

function HandleDuoStatus(player)
    local partner, reason = GetDuoPartner(player)

    if partner == nil then
        if reason == "offline" then
            SendChat(player, "Seu duo esta OFFLINE.")
        else
            SendChat(player, "Duo nao configurado. Use /duo set NOME.")
        end
        return
    end

    local myPosition = GetPlayerPosition(player)
    local partnerPosition = GetPlayerPosition(partner)
    local distance = CalculateDistance(myPosition, partnerPosition)

    SendChat(
        player,
        "Duo: " .. GetPlayerName(partner)
            .. " | Status: ONLINE | Distancia: "
            .. string.format("%.1f", distance)
            .. "m"
    )
end

function HandleLocalizarDuo(player)
    local partner, reason = GetDuoPartner(player)

    if partner == nil then
        if reason == "offline" then
            SendChat(player, "Seu duo esta offline.")
        else
            SendChat(player, "Duo nao configurado. Use /duo set NOME.")
        end
        return
    end

    local myPosition = GetPlayerPosition(player)
    local partnerPosition = GetPlayerPosition(partner)

    if partnerPosition == nil then
        SendChat(player, "Nao foi possivel obter a posicao do duo.")
        return
    end

    local distance = CalculateDistance(myPosition, partnerPosition)

    SendChat(
        player,
        GetPlayerName(partner)
            .. " esta em X=" .. string.format("%.0f", partnerPosition.x)
            .. " Y=" .. string.format("%.0f", partnerPosition.y)
            .. " Z=" .. string.format("%.0f", partnerPosition.z)
            .. " | Distancia: " .. string.format("%.1f", distance) .. "m"
    )
end

-- ============================================================
-- COMMAND LIST
-- ============================================================

function HandleListCommand(player)
    SendChat(player, "=== duo_supermod commands ===")
    SendChat(player, "/list - show this command list")
    SendChat(player, "/skin - list available skins")
    SendChat(player, "/skin default | /skin 1 | /skin 2 | /skin police | /skin gang")
    SendChat(player, "/skin id NUMBER - test a skin model ID")
    SendChat(player, "/vehicles - list vehicle commands")
    SendChat(player, "/bike | /heli | /plane | /car")
    SendChat(player, "/veh id NUMBER - test a vehicle model ID")
    SendChat(player, "/duo - show duo help")
    SendChat(player, "/duo set NAME | /duo clear")
    SendChat(player, "/tpduo | /bringduo | /duostatus | /findduo")
    SendChat(player, "/duohud - toggle the client HUD")
end

-- ============================================================
-- EVENTOS
-- ============================================================

function OnPlayerChat(args)
    local player = args.player
    local text = args.text

    if player == nil or text == nil or text == "" then
        return true
    end

    if string.sub(text, 1, 1) ~= "/" then
        return true
    end

    local parts = {}
    for word in string.gmatch(text, "%S+") do
        table.insert(parts, word)
    end

    local command = string.lower(string.sub(parts[1] or "", 2))
    local commandArgs = {}

    for i = 2, #parts do
        table.insert(commandArgs, parts[i])
    end

    if command == "list" then
        HandleListCommand(player)
        return false
    end

    if command == "skin" then
        HandleSkinCommand(player, commandArgs)
        return false
    end

    if command == "vehicles"
        or command == "bike"
        or command == "heli"
        or command == "plane"
        or command == "car"
        or command == "veh"
        -- Legacy Portuguese aliases
        or command == "veiculos"
        or command == "moto"
        or command == "aviao"
        or command == "carro"
    then
        HandleVehicleCommand(player, command, commandArgs)
        return false
    end

    if command == "duo" then
        HandleDuoCommand(player, commandArgs)
        return false
    end

    if command == "tpduo" then
        HandleTpDuo(player)
        return false
    end

    if command == "bringduo" or command == "trazerduo" then
        HandleTrazarDuo(player)
        return false
    end

    if command == "duostatus" then
        HandleDuoStatus(player)
        return false
    end

    if command == "findduo" or command == "localizarduo" then
        HandleLocalizarDuo(player)
        return false
    end

    -- Nao bloqueia comandos/mensagens de outros modulos.
    return true
end

function OnPlayerJoin(args)
    local player = args.player

    if player == nil then
        return
    end

    DebugLog("Jogador conectado: " .. GetPlayerName(player))
    SendChat(player, "Welcome! Type /list to see all duo_supermod commands.")
end

function OnPlayerQuit(args)
    local player = args.player

    if player == nil then
        return
    end

    local name = GetPlayerName(player)
    local key = GetPlayerKey(player)

    if key ~= nil then
        local vehicle = PlayerVehicles[key]

        if vehicle ~= nil and IsValid(vehicle) then
            pcall(function()
                vehicle:Remove()
            end)
        end

        VehCooldown[key] = nil
        TpCooldown[key] = nil
        PlayerVehicles[key] = nil

        -- DuoPairs nao e limpo: preserva a escolha enquanto o servidor continuar ligado.
    end

    DebugLog("Jogador desconectado: " .. name)
end

print("[duo_supermod] Carregando modulo duo_supermod v1.0.0...")

Events:Subscribe("PlayerChat", OnPlayerChat)
Events:Subscribe("PlayerJoin", OnPlayerJoin)
Events:Subscribe("PlayerQuit", OnPlayerQuit)

print("[duo_supermod] Evento PlayerChat registrado.")
print("[duo_supermod] Eventos PlayerJoin/PlayerQuit registrados.")
print("[duo_supermod] Modulo carregado. Pronto!")
