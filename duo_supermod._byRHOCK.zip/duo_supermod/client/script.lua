--[[
================================================================================
  duo_supermod - client/script.lua
  Simple HUD and visual messages.

  Comando client:
    /duohud - Liga/desliga o HUD de informacoes

  Este client nao executa skins, veiculos ou teleporte.
  Esses comandos continuam sendo tratados pelo server/script.lua.
================================================================================
]]

local hudAtivo = false

local HUD_LINES = {
    "duo_supermod active",
    "/list | /skin | /vehicles | /duo",
    "/tpduo | /bringduo | /duostatus | /findduo",
    "/duohud (close)",
}

local function IsGameActive()
    return Game:GetState() == GUIState.Game
end

local function DrawHUD()
    if not hudAtivo then
        return
    end

    if not IsGameActive() then
        return
    end

    Render:FillArea(
        Vector2(5, 5),
        Vector2(400, 14 + (#HUD_LINES * 18)),
        Color(0, 0, 0, 140)
    )

    for i, line in ipairs(HUD_LINES) do
        Render:DrawText(
            Vector2(10, 6 + ((i - 1) * 18)),
            line,
            Color(255, 220, 100, 230),
            14
        )
    end
end

local function OnLocalPlayerChat(args)
    local text = args.text or ""

    if text == "" or string.sub(text, 1, 1) ~= "/" then
        return true
    end

    local firstWord = string.match(text, "^(%S+)") or ""
    local command = string.lower(string.sub(firstWord, 2))

    if command ~= "duohud" then
        -- Important: let /list, /skin, /vehicles, /duo, etc. reach the server.
        return true
    end

    hudAtivo = not hudAtivo

    if hudAtivo then
        Chat:Print("[duo_supermod] HUD enabled.", Color(100, 255, 100))
    else
        Chat:Print("[duo_supermod] HUD disabled.", Color(255, 100, 100))
    end

    -- /duohud is client-side only; do not send it to the server.
    return false
end

Events:Subscribe("Render", DrawHUD)
Events:Subscribe("LocalPlayerChat", OnLocalPlayerChat)

print("[duo_supermod][CLIENT] Script loaded. Use /duohud to toggle the HUD.")
